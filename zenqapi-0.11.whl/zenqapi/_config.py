test_url = "https://demo.zen-q.com"
prod_url = "http://trade.zen-q.com"

place_order_url = "/API/V2/PlaceOrderAPI.php?"
search_ticker_url = "/API/V2/SearchTickerAPI.php?"
order_list_url = "/zenqapi/OrdersListAPI3.php?"
modify_order_url = "/zenqapi/ModifyOrderAPI.php?"
cancel_order_url = "/zenqapi/ChangeOrderStatusAPI.php?"
user_balances_url = "/API/V2/UserBalancesPortfolio.php?"
